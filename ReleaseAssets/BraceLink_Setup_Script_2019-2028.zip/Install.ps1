<#
.SYNOPSIS
    BraceLink Multi-Version Script-Based Installer (Revit 2019 - 2028)
.DESCRIPTION
    Installs BraceLink add-in directly to Revit add-in folders without triggering
    Microsoft Defender SmartScreen executable warnings. Supports current user and all-users deployments.
#>

param(
    [switch]$AllUsers,
    [switch]$Silent,
    [string[]]$Years = @()
)

$ErrorActionPreference = 'Stop'
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path

# If running directly from the repository tree, files are in RepoRoot\Output and RepoRoot\Deploy
# If running from a standalone packaged zip, files are in $ScriptDir\Files
$IsStandaloneZip = Test-Path (Join-Path $ScriptDir 'Files')

Write-Host "=================================================================" -ForegroundColor Cyan
Write-Host " BraceLink Script Installer (Revit 2019 - 2028)                  " -ForegroundColor Cyan
Write-Host "=================================================================" -ForegroundColor Cyan

$TargetBase = if ($AllUsers) {
    "C:\ProgramData\Autodesk\Revit\Addins"
} else {
    "$env:APPDATA\Autodesk\Revit\Addins"
}

Write-Host "Installation Target: $TargetBase" -ForegroundColor Gray
if ($AllUsers) {
    Write-Host "Scope: All Users (Machine-wide)" -ForegroundColor Yellow
} else {
    Write-Host "Scope: Current User (%APPDATA%)" -ForegroundColor Green
}
Write-Host ""

$AllYears = @('2019', '2020', '2021', '2022', '2023', '2024', '2025', '2026', '2027', '2028')
if ($Years.Count -gt 0) {
    $TargetYears = $Years
} else {
    $TargetYears = $AllYears
}

$installedCount = 0

# Clean any old pending auto-updater cache so stale updates don't overwrite this install
$pendingUpdate = Join-Path $env:APPDATA "BraceLink\PendingUpdate"
if (Test-Path $pendingUpdate) {
    Remove-Item -Path $pendingUpdate -Recurse -Force -ErrorAction SilentlyContinue
}

foreach ($year in $TargetYears) {
    $addinFile = $null
    $filesDir = $null

    if ($IsStandaloneZip) {
        $yearDir = Join-Path $ScriptDir "Files\$year"
        $addinCandidate = Join-Path $yearDir "BraceLink.addin"
        $filesCandidate = Join-Path $yearDir "BraceLink"

        if (Test-Path $addinCandidate) { $addinFile = $addinCandidate }
        if (Test-Path $filesCandidate) { $filesDir = $filesCandidate }
    } else {
        # Running from repository structure
        $repoRoot = Split-Path -Parent $ScriptDir
        $addinCandidate = Join-Path $repoRoot "Deploy\$year\BraceLink.addin"
        $filesCandidate = Join-Path $repoRoot "Output\$year\BraceLink"

        if (Test-Path $addinCandidate) { $addinFile = $addinCandidate }
        if (Test-Path $filesCandidate) { $filesDir = $filesCandidate }
    }

    if (-not $addinFile -or -not $filesDir) {
        Write-Host "  [-] Revit $year : Build files not found (skipped)" -ForegroundColor DarkGray
        continue
    }

    $destYearDir = Join-Path $TargetBase $year
    $destBraceLinkDir = Join-Path $destYearDir "BraceLink"
    $destManifest = Join-Path $destYearDir "BraceLink.addin"
    $disabledAddin = Join-Path $destYearDir "BraceLink.addin.disabled_by_quickloader"

    try {
        # 1. Cleanly delete old version directories and manifests before installing
        if (Test-Path $destBraceLinkDir) {
            Remove-Item -Path $destBraceLinkDir -Recurse -Force -ErrorAction SilentlyContinue
        }
        if (Test-Path $destManifest) {
            Remove-Item -Path $destManifest -Force -ErrorAction SilentlyContinue
        }
        if (Test-Path $disabledAddin) {
            Remove-Item -Path $disabledAddin -Force -ErrorAction SilentlyContinue
        }

        # 2. Ensure destination directory structure exists
        if (-not (Test-Path $destYearDir)) {
            New-Item -ItemType Directory -Path $destYearDir -Force | Out-Null
        }
        if (-not (Test-Path $destBraceLinkDir)) {
            New-Item -ItemType Directory -Path $destBraceLinkDir -Force | Out-Null
        }

        # 3. Copy manifest
        Copy-Item -Path $addinFile -Destination $destYearDir -Force

        # 4. Copy files and assets (clean overwrite)
        Copy-Item -Path (Join-Path $filesDir '*') -Destination $destBraceLinkDir -Recurse -Force

        Write-Host "  [+] Revit $year : Successfully installed (clean overwrite)" -ForegroundColor Green
        $installedCount++
    }
    catch {
        Write-Host "  [!] Revit $year : Installation failed - $($_.Exception.Message)" -ForegroundColor Red
    }
}

Write-Host ""
Write-Host "=================================================================" -ForegroundColor Cyan
if ($installedCount -gt 0) {
    Write-Host " Installation completed successfully for $installedCount Revit version(s)!" -ForegroundColor Green
    Write-Host " You can now launch Autodesk Revit and start using BraceLink." -ForegroundColor White
} else {
    Write-Host " No Revit versions were installed. Ensure build output files exist." -ForegroundColor Yellow
}
Write-Host "=================================================================" -ForegroundColor Cyan
Write-Host ""
