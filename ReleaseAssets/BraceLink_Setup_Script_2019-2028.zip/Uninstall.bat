@echo off
setlocal
echo.
echo =================================================================
echo   BraceLink Multi-Version Script Uninstaller (Revit 2019 - 2028)
echo =================================================================
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Uninstall.ps1" %*
echo.
echo Press any key to exit...
pause >nul
exit /b 0
