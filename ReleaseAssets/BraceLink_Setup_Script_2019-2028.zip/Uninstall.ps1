<#
.SYNOPSIS
    BraceLink Multi-Version Script-Based Uninstaller (Revit 2019 - 2028)
.DESCRIPTION
    Cleans up BraceLink add-in manifests and files across all Revit versions.
#>

param(
    [switch]$AllUsers
)

$ErrorActionPreference = 'SilentlyContinue'

Write-Host "=================================================================" -ForegroundColor Cyan
Write-Host " BraceLink Script Uninstaller (Revit 2019 - 2028)                " -ForegroundColor Cyan
Write-Host "=================================================================" -ForegroundColor Cyan
Write-Host ""

$Targets = @("$env:APPDATA\Autodesk\Revit\Addins")
if ($AllUsers -or (Test-Path "C:\ProgramData\Autodesk\Revit\Addins")) {
    $Targets += "C:\ProgramData\Autodesk\Revit\Addins"
}

$AllYears = @('2019', '2020', '2021', '2022', '2023', '2024', '2025', '2026', '2027', '2028')
$removedCount = 0

foreach ($base in $Targets) {
    if (-not (Test-Path $base)) { continue }

    foreach ($year in $AllYears) {
        $yearDir = Join-Path $base $year
        $manifest = Join-Path $yearDir "BraceLink.addin"
        $disabledManifest = Join-Path $yearDir "BraceLink.addin.disabled_by_quickloader"
        $filesDir = Join-Path $yearDir "BraceLink"

        $found = $false

        if (Test-Path $manifest) {
            Remove-Item $manifest -Force
            $found = $true
        }
        if (Test-Path $disabledManifest) {
            Remove-Item $disabledManifest -Force
            $found = $true
        }
        if (Test-Path $filesDir) {
            Remove-Item $filesDir -Recurse -Force
            $found = $true
        }

        if ($found) {
            Write-Host "  [-] Cleaned BraceLink from Revit $year ($base)" -ForegroundColor Yellow
            $removedCount++
        }
    }
}

Write-Host ""
Write-Host "=================================================================" -ForegroundColor Cyan
Write-Host " Cleanup completed. Removed $removedCount installation instance(s)." -ForegroundColor Green
Write-Host "=================================================================" -ForegroundColor Cyan
Write-Host ""
