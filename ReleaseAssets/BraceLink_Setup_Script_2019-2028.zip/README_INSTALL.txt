================================================================================
BraceLink Multi-Version Script Installer (Revit 2019 - 2028)
================================================================================

This package installs the BraceLink Revit add-in for any installed Autodesk Revit
versions (2019 through 2028).

Because this installer uses native Windows batch and PowerShell scripts, it does
NOT trigger Microsoft Defender SmartScreen executable warnings.

--------------------------------------------------------------------------------
HOW TO INSTALL FOR YOURSELF (STANDARD TEAM MEMBER):
--------------------------------------------------------------------------------
1. Extract all contents of this ZIP file to any folder on your computer.
2. Double-click "Install.bat".
3. The script will copy BraceLink files into your personal Revit Addins folder
   (%APPDATA%\Autodesk\Revit\Addins\{year}\).
4. Launch Autodesk Revit -- the "BraceLink" tab will appear on the ribbon!

--------------------------------------------------------------------------------
HOW TO INSTALL FOR ALL USERS (IT ADMINISTRATORS):
--------------------------------------------------------------------------------
Open PowerShell or Command Prompt as Administrator and run:
   Install.bat -AllUsers
   (or: powershell -ExecutionPolicy Bypass -File .\Install.ps1 -AllUsers)

This installs BraceLink into C:\ProgramData\Autodesk\Revit\Addins\{year}\ so that
any user logging into the computer will have access to the add-in.

--------------------------------------------------------------------------------
HOW TO UNINSTALL:
--------------------------------------------------------------------------------
1. Double-click "Uninstall.bat".
   (For all-users installations, run: Uninstall.bat -AllUsers from admin prompt).
================================================================================
