@echo off
setlocal
echo.
echo =================================================================
echo   BraceLink Multi-Version Script Installer (Revit 2019 - 2028)
echo =================================================================
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install.ps1" %*
if errorlevel 1 (
    echo.
    echo Installation reported errors.
    pause
    exit /b 1
)

echo.
echo Press any key to exit...
pause >nul
exit /b 0
